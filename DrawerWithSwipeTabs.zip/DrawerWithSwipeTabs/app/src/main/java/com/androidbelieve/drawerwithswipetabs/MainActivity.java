package com.androidbelieve.drawerwithswipetabs;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.CalendarView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    DrawerLayout mDrawerLayout;
    NavigationView mNavigationView;
    FragmentManager mFragmentManager;
    FragmentTransaction mFragmentTransaction;
    CalendarView calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        /**
         *Setup the DrawerLayout and NavigationView
         */

        calendar=(CalendarView) findViewById(R.id.calendarView);
         /*calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                Toast.makeText(getApplicationContext(), dayOfMonth + "/" + month + "/" + year, Toast.LENGTH_LONG).show();
            }
        });*/


        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        mNavigationView = (NavigationView) findViewById(R.id.shitstuff);

        /**
         * Lets inflate the very first fragment
         * Here , we are inflating the TabFragment as the first Fragment
         */

        mFragmentManager = getSupportFragmentManager();
        mFragmentTransaction = mFragmentManager.beginTransaction();
        mFragmentTransaction.replace(R.id.containerView, new TabFragment()).commit();
        /**
         * Setup click events on the Navigation View Items.
         */

        mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                mDrawerLayout.closeDrawers();


                if (menuItem.getItemId() == R.id.nav_item_tt) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new TimeTableFragment()).commit();

                }

                if (menuItem.getItemId() == R.id.nav_item_announcement) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new Announcements()).commit();

                }


                if (menuItem.getItemId() == R.id.nav_item_internship) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new Internships()).commit();

                }
                if (menuItem.getItemId() == R.id.nav_item_MyProfile) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new Myprofile()).commit();

                }
                if (menuItem.getItemId() == R.id.nav_item_About) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new About()).commit();

                }
                if (menuItem.getItemId() == R.id.nav_item_Help) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new Help()).commit();

                }
                if (menuItem.getItemId() == R.id.nav_item_Settings) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new Settings()).commit();

                }

                if (menuItem.getItemId() == R.id.nav_item_home) {
                    FragmentTransaction xfragmentTransaction = mFragmentManager.beginTransaction();
                    xfragmentTransaction.replace(R.id.containerView, new TabFragment()).commit();
                }

                return false;
            }

        });


        /**
         * Setup Drawer Toggle of the Toolbar
         */

        android.support.v7.widget.Toolbar toolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        ActionBarDrawerToggle mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.app_name,
                R.string.app_name);

        mDrawerLayout.setDrawerListener(mDrawerToggle);

        mDrawerToggle.syncState();


    }
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this.getBaseContext());
        final CharSequence[] items = {
                "Medical electronics", "Stochastic", "Indian Cities and Literature"
        };

        builder.setTitle("Pick a Subject").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // The 'which' argument contains the index position
                // of the selected item
            }
        });
        return builder.create();

    }

    public void open6(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final CharSequence[] items = {
                "Medical electronics", "Stochastic", "Indian Cities and Literature"
        };

        builder.setTitle("Subjects of Slot 6").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // The 'which' argument contains the index position
                // of the selected item
                Toast.makeText(MainActivity.this, "You clicked"+dialog.toString()+"button", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }
    public void open7(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final CharSequence[] items = {
                "Software Engineering", "Stochastic", "Indian Cities and Literature"
        };

        builder.setTitle("Subjects of Slot 7").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // The 'which' argument contains the index position
                // of the selected item
                Toast.makeText(MainActivity.this, "You clicked"+dialog.toString()+"button", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }
    public void open5(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final CharSequence[] items = {
                "Stat com", "Crypto", "Indian Cities and Literature"
        };

        builder.setTitle("Subjects of Slot 5").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // The 'which' argument contains the index position
                // of the selected item
                Toast.makeText(MainActivity.this, "You clicked"+dialog.toString()+"button", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }
    public void open4(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final CharSequence[] items = {
                "MOC", "SSD", "Ray"
        };

        builder.setTitle("Subjects of Slot 4").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // The 'which' argument contains the index position
                // of the selected item
                Toast.makeText(MainActivity.this, "You clicked"+dialog.toString()+"button", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }
    public void open3(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final CharSequence[] items = {
                "OS", "Stochastic", "Indian Cities and Literature"
        };

        builder.setTitle("Subjects of Slot 3").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // The 'which' argument contains the index position
                // of the selected item
                Toast.makeText(MainActivity.this, "You clicked"+dialog.toString()+"button", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }
    public void open2(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final CharSequence[] items = {
                "Nano", "Web data", "Indian Cities and Literature"
        };

        builder.setTitle("Subjects of Slot 2").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // The 'which' argument contains the index position
                // of the selected item
                Toast.makeText(MainActivity.this, "You clicked"+dialog.toString()+"button", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }
    public void open1(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final CharSequence[] items = {
                "NPA", "IOT", "DSA"
        };

        builder.setTitle("Subjects of Slot 1").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // The 'which' argument contains the index position
                // of the selected item
                Toast.makeText(MainActivity.this, "You clicked"+dialog.toString()+"button", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }
    public void SaveChanges(View view) {
        Toast.makeText(this, "Changes Saved", Toast.LENGTH_SHORT).show();
    }



}
